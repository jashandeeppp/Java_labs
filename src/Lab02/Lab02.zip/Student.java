package Lab02;

import java.util.ArrayList;

interface Student {
	public void addGrades(ArrayList<Integer> grades);
	public void removeGrades(ArrayList<Integer> grades);
	public void assignCourse(String course);
}
