package Lab02;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		GraduateStudent grad = new GraduateStudent();
		ArrayList<Integer> grades = new ArrayList<Integer>();
		grades.add(89);
		grades.add(96);	
		grades.add(78);	
		grades.add(93);	
		grades.add(91);
		grad.assignCourse("Java OOPs");
		grad.displayinfo(grades);
		grad.addGrades(grades);
		grad.removeGrades(grades);


		UnderGradStudent undergrad = new UnderGradStudent();
		ArrayList<Integer> grades2 = new ArrayList<Integer>();
		grades2.add(59);
		grades2.add(54);	
		grades2.add(78);	
		grades2.add(82);	
		grades2.add(49);
		grades2.add(65);
		undergrad.assignCourse("DataStructure and Algorithm");
		undergrad.displayinfo(grades2);
		undergrad.addGrades(grades2);
		undergrad.removeGrades(grades2);


	}

}
